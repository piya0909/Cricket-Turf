// Calendar functionality with animations
function generateCalendar() {
    const calendar = document.getElementById('calendar');
    const date = new Date();
    const month = date.getMonth();
    const year = date.getFullYear();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    calendar.innerHTML = '';

    // Add empty cells with fade-in animation
    for (let i = 0; i < firstDay; i++) {
        const emptyDay = document.createElement('div');
        emptyDay.className = 'fade-in';
        calendar.appendChild(emptyDay);
        
        // Trigger animation after a delay
        setTimeout(() => emptyDay.classList.add('visible'), i * 50);
    }

    // Add days with staggered animation
    for (let day = 1; day <= daysInMonth; day++) {
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day p-2 text-center border rounded-lg fade-in';
        dayElement.textContent = day;

        if (Math.random() > 0.7) {
            dayElement.classList.add('booked', 'bg-red-100', 'text-red-800');
        } else {
            dayElement.classList.add('available', 'hover:bg-green-100');
            dayElement.addEventListener('click', () => generateTimeSlots());
        }

        calendar.appendChild(dayElement);
        
        // Trigger animation after a delay
        setTimeout(() => dayElement.classList.add('visible'), (firstDay + day) * 50);
    }
}

function generateTimeSlots() {
    const timeSlots = document.getElementById('timeSlots');
    const slots = [
        '06:00 AM', '07:00 AM', '08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM',
        '04:00 PM', '05:00 PM', '06:00 PM', '07:00 PM', '08:00 PM', '09:00 PM', '10:00 PM'
    ];

    timeSlots.innerHTML = '';

    slots.forEach((slot, index) => {
        const slotElement = document.createElement('div');
        slotElement.className = 'time-slot p-2 text-center border rounded-lg fade-in';
        slotElement.textContent = slot;

        if (Math.random() > 0.7) {
            slotElement.classList.add('booked', 'bg-red-100', 'text-red-800');
        } else {
            slotElement.classList.add('available', 'hover:bg-green-100');
            slotElement.addEventListener('click', () => selectTimeSlot(event));
        }

        timeSlots.appendChild(slotElement);
        
        // Trigger animation after a delay
        setTimeout(() => slotElement.classList.add('visible'), index * 50);
    });
}

function selectTimeSlot(event) {
    const allSlots = document.querySelectorAll('.time-slot');
    allSlots.forEach(s => s.classList.remove('bg-green-500', 'text-white'));
    event.target.classList.add('bg-green-500', 'text-white');
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    generateCalendar();
    generateTimeSlots();
});