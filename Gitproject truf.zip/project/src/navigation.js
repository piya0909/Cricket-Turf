// Navbar scroll behavior
let lastScroll = 0;
const navbar = document.getElementById('navbar');

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll <= 0) {
        navbar.style.transform = 'translateY(0)';
        return;
    }
    
    if (currentScroll > lastScroll && !navbar.classList.contains('scroll-down')) {
        // Scroll down
        navbar.style.transform = 'translateY(-100%)';
    } else if (currentScroll < lastScroll && navbar.classList.contains('scroll-down')) {
        // Scroll up
        navbar.style.transform = 'translateY(0)';
    }
    
    lastScroll = currentScroll;
});

// Mobile menu
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const mobileMenu = document.getElementById('mobileMenu');

mobileMenuBtn.addEventListener('click', () => {
    mobileMenu.classList.toggle('hidden');
    mobileMenu.classList.toggle('visible');
});

// Login Modal
const loginBtn = document.getElementById('loginBtn');
const loginModal = document.getElementById('loginModal');
const closeLoginModal = document.getElementById('closeLoginModal');
const mobilLoginBtn = document.querySelector('#mobileMenu button');

function openModal() {
    loginModal.classList.add('visible');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    loginModal.classList.remove('visible');
    document.body.style.overflow = '';
}

loginBtn.addEventListener('click', openModal);
mobilLoginBtn.addEventListener('click', openModal);
closeLoginModal.addEventListener('click', closeModal);

// Close modal when clicking outside
loginModal.addEventListener('click', (e) => {
    if (e.target === loginModal) {
        closeModal();
    }
});

// Close modal on escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && loginModal.classList.contains('visible')) {
        closeModal();
    }
});

// Jump to Top Button
const jumpToTopBtn = document.createElement('button');
jumpToTopBtn.className = 'jump-to-top';
jumpToTopBtn.innerHTML = '<i class="bi bi-arrow-up"></i>';
document.body.appendChild(jumpToTopBtn);

// Show/hide jump to top button
window.addEventListener('scroll', () => {
    if (window.pageYOffset > 500) {
        jumpToTopBtn.classList.add('visible');
    } else {
        jumpToTopBtn.classList.remove('visible');
    }
});

jumpToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Section Navigation
const sections = ['hero', 'facilities', 'booking', 'contact'];
const sectionNav = document.createElement('div');
sectionNav.className = 'section-nav';

sections.forEach(section => {
    const dot = document.createElement('div');
    dot.className = 'section-nav-dot';
    
    const label = document.createElement('span');
    label.className = 'section-nav-label';
    label.textContent = section.charAt(0).toUpperCase() + section.slice(1);
    
    dot.appendChild(label);
    dot.addEventListener('click', () => {
        const element = document.getElementById(section);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    });
    
    sectionNav.appendChild(dot);
});

document.body.appendChild(sectionNav);

// Update active section in navigation
const observerOptions = {
    threshold: 0.5
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        const id = entry.target.id;
        const dot = document.querySelector(`.section-nav-dot[data-section="${id}"]`);
        
        if (entry.isIntersecting && dot) {
            document.querySelectorAll('.section-nav-dot').forEach(d => d.classList.remove('active'));
            dot.classList.add('active');
        }
    });
}, observerOptions);

sections.forEach(section => {
    const element = document.getElementById(section);
    if (element) {
        observer.observe(element);
    }
});