export default {
  root: 'src'
}